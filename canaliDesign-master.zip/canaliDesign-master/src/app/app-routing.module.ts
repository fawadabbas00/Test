import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomePageComponent } from './components/home-page/home-page.component';
import { DesignComponent } from './components/design/design.component';
import { GridImageComponent } from './components/grid-image/grid-image.component';
import { SingleImgComponent } from './components/single-img/single-img.component';


const routes: Routes = [
  {
    path: '',
    component: HomePageComponent
  },
  {
    path: 'design',
    component: DesignComponent
  },
  {
    path: 'project-archive',
    component: GridImageComponent
  },
  {
    path: 'project-archive/:id',
    component: SingleImgComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
