import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgxMasonryModule } from 'ngx-masonry';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomePageComponent } from './components/home-page/home-page.component';
import { DesignComponent } from './components/design/design.component';
import { FooterComponent } from './components/footer/footer.component';
import { HeaderComponent } from './components/header/header.component';
import { GridImageComponent } from './components/grid-image/grid-image.component';
import { SingleImgComponent } from './components/single-img/single-img.component';

@NgModule({
  declarations: [
    AppComponent,
    HomePageComponent,
    DesignComponent,
    FooterComponent,
    HeaderComponent,
    GridImageComponent,
    SingleImgComponent
  ],
  imports: [
    BrowserAnimationsModule,
    NgxMasonryModule,
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
