import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-single-img',
  templateUrl: './single-img.component.html',
  styleUrls: ['./single-img.component.scss']
})

export class SingleImgComponent implements OnInit {  

  constructor() { }

  ngOnInit() {
  }

}
