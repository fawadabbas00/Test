import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-grid-image',
  templateUrl: './grid-image.component.html',
  styleUrls: ['./grid-image.component.scss']
})

export class GridImageComponent implements OnInit {

  masonryItems = [
    { id: '1', src: 'assets/images/Free-Nature-Backgrounds-Seaport-During-Daytime-by-Pexels.jpeg' },
    { title: 'Fiere di Brescia', sub: 'Corporate image catalogue & Exhibition' },
    { title: 'Nava Design', sub: 'Art Direction, catalogues, Exhibition shops ' },
    { id: '2', src: 'assets/images/background-texture-2110.jpg' },
    { id: '3', src: 'assets/images/pexels-photo-1227520.jpeg' },
    { title: 'Amarea', sub: 'Adv Campaign' },
    { title: 'Les First', sub: 'Corporate image catalogue Digital & Product' },
    { id: '4', src: 'assets/images/82c7d54e3ae5327cc4e1142d99eb2a86.jpg' },
  ];

  constructor() { }

  ngOnInit() {
  }



}
